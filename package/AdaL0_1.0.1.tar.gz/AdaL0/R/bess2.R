bess2 = function(x, y, family = c("gaussian", "binomial", "cox"),
                ic.coef = 5,
                s,
                max.steps = 30,
                max.iter = 10,
                eta = 0.9,
                epsilon = 1e-8,
                rho = 0.001,
                weights = rep(1,nrow(x)))
{
  fit = bess_lm2(X = x, y = y, eps = epsilon, max_steps = max.steps, max_iter = max.iter, eta = eta, rho = rho, weights = weights, s = s)
  out = list(family = "bess", beta = fit$beta)
  return(out)
}
