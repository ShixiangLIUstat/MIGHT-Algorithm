bess3 = function(x, y, family = c("gaussian", "binomial", "cox"),
                 ic.coef = 3,
                 s.list,
                 max.steps = 10,
                 eta = 0.8,
                 threshold = 1.5,
                 threshold2 = 1.5,
                 weights = rep(1,nrow(x)))
{
  if(ncol(x) == 1|is.vector(x)) stop("x should be two columns at least!")
  if(missing(s.list)) s.list = 1:min(ncol(x), round(nrow(x)/log(exp(1)*ncol(x))))
  fit = AdaL0::bess_lm_path3(X = x, y = y, max_steps = max.steps, eta = eta, weights = weights, T_list = s.list, ic_coef = ic.coef)
  A.out = apply(fit$beta, 2, function(x) return (which(x != 0)))
  size = which.min(fit$penalty)
  beta.min = apply(fit$beta, 2, function(x) { min(abs(x)[which(x!=0)])})
  # mse.rate = fit$mse[-length(s.list)]/fit$mse[-1]
  # temp1 = which(mse.rate>= threshold2)
  # if (length(temp1) != 0) {
  #   ind1 = (max(temp1)+1):length(s.list)
  #   ind2 = ceiling(size/2):min(c(2*size, max(s.list)))
  #   ind = intersect(ind1, ind2) 
  # } else {
  #   ind = ceiling(size/2):min(c(2*size, max(s.list)))
  # }
  if (size >1) {
    ind = ceiling(size/2):min(c(2*size, max(s.list)))
  } else {
    ind = 1:min(c(2*size, max(s.list)))
  }
  beta.rate = beta.min[-length(beta.min)]/beta.min[-1]
  
  temp = which(beta.rate[ind]>= threshold)
  if (length(temp) == 0) {
    best.size = size
    best.coef = rep(0, ncol(x)+1)
    best.coef[-1] = fit$beta[, best.size]
    best.coef[1] = fit$intercept[best.size]
  } else {
    best.size = max(ind[temp])
    sigma_hat = norm((y-x%*%as.vector(fit$beta[, size])), type = "2")/sqrt(nrow(x))
    if (norm(fit$beta[, best.size]-fit$beta[, size], type = "2") > 5*sigma_hat*sqrt(2*size*log(ncol(x))/nrow(x))) {
      best.size = size
    }
    best.subset = which(fit$beta[, best.size] != 0)
    best.coef = rep(0, ncol(x)+1)
    best.coef[-1] = fit$beta[, best.size]
    best.coef[1] = fit$intercept[best.size]
  }
  out = list(family = "bess", beta = fit$beta, intercept = fit$intercept, s.list = s.list,
             mse = fit$mse, penalty = fit$penalty, A.out = A.out, best.size = best.size, best.coef = best.coef, iter.num = fit$iter_num)
  return(out)
}
