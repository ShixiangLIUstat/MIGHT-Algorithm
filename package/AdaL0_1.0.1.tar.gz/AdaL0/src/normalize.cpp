#include <Rcpp.h>
#include <RcppEigen.h>
#include <algorithm>
#include <vector>
// [[Rcpp::depends(RcppEigen)]]
using namespace Rcpp;
using namespace std;

void Normalize(Eigen::MatrixXf& X, Eigen::VectorXf& y, Eigen::VectorXf& weights, Eigen::VectorXf& meanx, float& meany, Eigen::VectorXf& normx){
  int n = X.rows();
  int p = X.cols();
  Eigen::VectorXf tmp(n);
  for (int i=0;i<p;i++) {
    meanx(i) = weights.dot(X.col(i))/float(n);
  }
  meany = (y.dot(weights))/float(n);
  for(int i=0;i<p;i++){
    X.col(i) = X.col(i).array() - meanx(i);
  }
  y = y.array() - meany;
  for (int i=0;i<p;i++) {
    tmp = X.col(i);
    tmp = tmp.array().square();
    normx(i) = sqrt(weights.dot(tmp));
  }
  for (int i=0;i<p;i++) {
    X.col(i) = sqrt(float(n))*X.col(i)/normx(i);
  }
}

