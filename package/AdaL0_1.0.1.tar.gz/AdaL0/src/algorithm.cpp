#include <Rcpp.h>
#include <RcppEigen.h>
using namespace Rcpp;
// [[Rcpp::plugins("cpp11")]]
// [[Rcpp::depends(RcppEigen)]]
#include <iostream>
#include <vector>
#include "normalize.h"
#include "utilities.h"
using namespace Eigen;
using namespace std;

int bess_lm(Eigen::MatrixXf& X, Eigen::VectorXf& y, Eigen::VectorXf& beta, int s, float eps, int max_steps, int max_iter, float eta) {
  int i = 0;
  int n = X.rows();
  int p = X.cols();
  float t = 1;
  Eigen::VectorXf beta1 = Eigen::VectorXf::Zero(p);
  Eigen::VectorXf d = X.transpose()*(y-X*beta)/float(n);
  for (i = 0; i < max_steps; i++) {
    beta1 = backtracking(X, y, beta, d, t, s, max_iter, eta, eta);
    if ((beta1-beta).squaredNorm() <= eps) {
      break;
    } else {
      beta = beta1;
      d = X.transpose()*(y-X*beta1)/float(n);
    }
  }
  // int size = 0;
  // for (int j = 0;j<p;j++){
  //   if ( beta(j) != 0) {
  //     size = size+1;
  //   }
  // }
  // Rcout<<"size:"<<size<<"\n";
  return(i);
}

// [[Rcpp::export]]
List bess_lm_path(Eigen::MatrixXf& X, Eigen::VectorXf& y, float eps, int max_steps, int max_iter, float eta, Eigen::VectorXf& weights, Eigen::VectorXi& T_list, float ic_coef) 
{
    int n = X.rows();
    int p = X.cols();
    int m = T_list.size();
    float meany = 0.0;
    Eigen::VectorXi iter_num = Eigen::VectorXi::Zero(m);
    Eigen::VectorXf mse = Eigen::VectorXf::Zero(m);
    Eigen::VectorXf pen = Eigen::VectorXf::Zero(m);
    Eigen::VectorXf intercept = Eigen::VectorXf::Zero(m);
    Eigen::VectorXf meanx = Eigen::VectorXf::Zero(p);
    Eigen::VectorXf normx = Eigen::VectorXf::Zero(p);
    Eigen::VectorXf beta = Eigen::VectorXf::Zero(p);
    Eigen::MatrixXf beta_out = Eigen::MatrixXf::Zero(p, m);
    Normalize(X, y, weights, meanx, meany, normx);
    for(int i = 0; i<m; i++){
      iter_num(i) = bess_lm(X, y, beta, T_list(i), eps, max_steps, max_iter, eta);
      beta_out.col(i) = beta;
      mse(i) = (y-X*beta_out.col(i)).squaredNorm()/float(n);
      pen(i) = float(n)*log(mse(i))+ic_coef*log(exp(1)*float(p)/T_list(i))*T_list(i);
    }
    for(int i=0;i<m;i++){
      beta_out.col(i) = sqrt(float(n))*beta_out.col(i).cwiseQuotient(normx);
      intercept(i) = meany - beta_out.col(i).dot(meanx);
    }
    return List::create(Named("beta")=beta_out, Named("intercept")=intercept, Named("mse")=mse, Named("penalty")=pen, Named("iter_num")=iter_num);
} 

int bess_lm3(Eigen::MatrixXf& X, Eigen::VectorXf& y, Eigen::VectorXf& beta, int s, int max_steps, float eta) {
  int i = 0;
  int n = X.rows();
  int p = X.cols();
  vector<int> A(s, -1);
  vector<int> B(s, -1);
  Eigen::MatrixXf X_A(n, s);
  Eigen::MatrixXf XtX(s, s);
  Eigen::VectorXf beta_A(s);
  Eigen::VectorXf beta1 = Eigen::VectorXf::Zero(p);
  Eigen::VectorXf temp = Eigen::VectorXf::Zero(p);
  Eigen::VectorXf d = X.transpose()*(y-X*beta)/float(n);
  for (i = 0; i < max_steps; i++) {
    temp = beta + eta*d;
    A = max_k(temp.cwiseAbs(), s);
    // Rcout<<"--------\n";
    // for (int i = 0; i < s; i++) {
    //   Rcout<<A[i]<<" ";
    // }
    // Rcout<<"\n";
    if (A == B) {
      break;
    } else {
      for(int i=0;i<s;i++) {
        X_A.col(i) = X.col(A[i]);
      }
      XtX = X_A.transpose() * X_A;
      XtX.diagonal().array() += 1e-6f;  // 正则化
      LLT<MatrixXf> llt(XtX);
      beta_A = llt.solve(X_A.transpose() * y);
      beta = Eigen::VectorXf::Zero(p);
      for (int j = 0; j < s; j++) {
        beta(A[j]) = beta_A(j);
      }
      d = X.transpose()*(y-X*beta)/float(n);
      beta1 = Eigen::VectorXf::Zero(p);
      B = A;
    }
  }
  return(i);
}

// [[Rcpp::export]]
List bess_lm_path3(Eigen::MatrixXf& X, Eigen::VectorXf& y, int max_steps, float eta, Eigen::VectorXf& weights, Eigen::VectorXi& T_list, float ic_coef) 
{
  int n = X.rows();
  int p = X.cols();
  int m = T_list.size();
  float meany = 0.0;
  Eigen::VectorXi iter_num = Eigen::VectorXi::Zero(m);
  Eigen::VectorXf mse = Eigen::VectorXf::Zero(m);
  Eigen::VectorXf pen = Eigen::VectorXf::Zero(m);
  Eigen::VectorXf intercept = Eigen::VectorXf::Zero(m);
  Eigen::VectorXf meanx = Eigen::VectorXf::Zero(p);
  Eigen::VectorXf normx = Eigen::VectorXf::Zero(p);
  Eigen::VectorXf beta = Eigen::VectorXf::Zero(p);
  Eigen::MatrixXf beta_out = Eigen::MatrixXf::Zero(p, m);
  Normalize(X, y, weights, meanx, meany, normx);
  for(int i = 0; i<m; i++){
    iter_num(i) = bess_lm3(X, y, beta, T_list(i), max_steps, eta);
    beta_out.col(i) = beta;
    mse(i) = (y-X*beta_out.col(i)).squaredNorm()/float(n);
    pen(i) = float(n)*log(mse(i))+ic_coef*log(exp(1)*float(p)/T_list(i))*T_list(i);
  }
  for(int i=0;i<m;i++){
    beta_out.col(i) = sqrt(float(n))*beta_out.col(i).cwiseQuotient(normx);
    intercept(i) = meany - beta_out.col(i).dot(meanx);
  }
  return List::create(Named("beta")=beta_out, Named("intercept")=intercept, Named("mse")=mse, Named("penalty")=pen, Named("iter_num")=iter_num);
} 

// [[Rcpp::export]]
List bess_lm2(Eigen::MatrixXf& X, Eigen::VectorXf& y, Eigen::VectorXf& weights, int s, float eps, int max_steps, int max_iter, float eta, float rho) {
  int n = X.rows();
  int p = X.cols();
  float meany = 0.0;
  Eigen::MatrixXf beta_out = Eigen::MatrixXf::Zero(p, max_steps);
  Eigen::VectorXf meanx = Eigen::VectorXf::Zero(p);
  Eigen::VectorXf normx = Eigen::VectorXf::Zero(p);
  Normalize(X, y, weights, meanx, meany, normx);
  float t = 1;
  Eigen::VectorXf beta = Eigen::VectorXf::Zero(p);
  Eigen::VectorXf res = (y-X*beta)/float(n);
  Eigen::VectorXf beta1 = Eigen::VectorXf::Zero(p);
  Eigen::VectorXf d = Eigen::VectorXf::Zero(p);
  for(int i=0;i<p;i++){
    d(i) = res.dot(X.col(i));
  }
  for (int i = 0; i < max_steps; i++) {
    beta1 = backtracking(X, y, beta, d, t, s, max_iter, eta, rho);
    if ((beta1-beta).squaredNorm() <= eps) {
      break;
    } else {
      beta = beta1;
      d = X.transpose()*(y-X*beta1)/float(n);
      beta_out.col(i) = beta1;
    }
  }
  for(int i=0;i<max_steps;i++){
    beta_out.col(i) = sqrt(float(n))*beta_out.col(i).cwiseQuotient(normx);
  }
  return List::create(Named("beta")=beta_out);
}
