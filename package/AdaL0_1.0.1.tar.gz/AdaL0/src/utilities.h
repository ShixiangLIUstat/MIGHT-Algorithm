#ifndef tmp_H
#define tmp_H

#include <vector>
using namespace std;
Eigen::VectorXf backtracking(Eigen::MatrixXf& X, Eigen::VectorXf& y, Eigen::VectorXf beta, Eigen::VectorXf d, float t, int s, int max_iter, float eta, float rho);
Eigen::VectorXf backtracking2(Eigen::MatrixXf& X, Eigen::VectorXf& y, Eigen::VectorXf beta, Eigen::VectorXf d, float t, int s, int max_iter, float eta);
std::vector<int> max_k(Eigen::VectorXf L, int k);

#endif
