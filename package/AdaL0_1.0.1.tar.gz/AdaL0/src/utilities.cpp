#include <Rcpp.h>
#include <RcppEigen.h>
#include <algorithm>
#include <vector>
// [[Rcpp::depends(RcppEigen)]]
using namespace Rcpp;
using namespace std;
// [[Rcpp::export]]
std::vector<int> max_k(Eigen::VectorXf L, int k)
{
  std::vector<int> vec(k);
  for (int i=0;i<k;i++) 
  {
    L.maxCoeff(&vec[i]);
    L(vec[i])=-1;
  }
  sort(vec.begin(), vec.end());
  return vec;
}

// [[Rcpp::export]]
Eigen::VectorXf backtracking(Eigen::MatrixXf& X, Eigen::VectorXf& y, Eigen::VectorXf beta, Eigen::VectorXf d, float t, int s, int max_iter, float eta, float rho) {
  int i = 0;
  int n = X.rows();
  int p = X.cols();
  vector<int> A(s);
  float loss = (y-X*beta).squaredNorm();
  Eigen::VectorXf beta1 = Eigen::VectorXf::Zero(p);
  Eigen::VectorXf temp = Eigen::VectorXf::Zero(p);
  for (i=0; i < max_iter;i++) {
    beta1 = Eigen::VectorXf::Zero(p);
    temp = beta + t*pow(eta, i)*d;
    A = max_k(temp.cwiseAbs(), s);
    for (int j = 0; j < s; j++) {
      beta1(A[j]) = temp(A[j]);
    }
    if (loss-(y-X*beta1).squaredNorm() >= n*rho*eta*(beta-beta1).squaredNorm()) {
      beta = beta1;
      break;
    } 
  }
  // Rcout<<"i:"<<i<<"\n";
  return beta;
}

// [[Rcpp::export]]
Eigen::VectorXf backtracking2(Eigen::MatrixXf& X, Eigen::VectorXf& y, Eigen::VectorXf beta, Eigen::VectorXf d, float t, int s, int max_iter, float eta) {
  int i = 0;
  int n = X.rows();
  int p = X.cols();
  vector<int> A(s);
  Eigen::MatrixXf X_A(n, s);
  Eigen::VectorXf beta_A(s);
  float loss = (y-X*beta).squaredNorm();
  Eigen::VectorXf beta1 = Eigen::VectorXf::Zero(p);
  Eigen::VectorXf temp = Eigen::VectorXf::Zero(p);
  for (i=0; i < max_iter;i++) {
    beta1 = Eigen::VectorXf::Zero(p);
    temp = beta + t*pow(eta, i)*d;
    A = max_k(temp.cwiseAbs(), s);
    for(int i=0;i<s;i++) {
      X_A.col(i) = X.col(A[i]);
    }
    beta_A = X_A.colPivHouseholderQr().solve(y);
    for (int j = 0; j < s; j++) {
      beta1(A[j]) = beta_A(j);
    }
    if (loss >= (y-X*beta1).squaredNorm()) {
      beta = beta1;
      break;
    } 
  }
  // Rcout<<"i:"<<i<<"\n";
  return beta;
}
