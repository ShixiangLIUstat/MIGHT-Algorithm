#ifndef normlize_H
#define normlize_H
#include <RcppEigen.h>

void Normalize(Eigen::MatrixXf& X, Eigen::VectorXf& y, Eigen::VectorXf& weights, Eigen::VectorXf& meanx, float& meany, Eigen::VectorXf& normx);

#endif
