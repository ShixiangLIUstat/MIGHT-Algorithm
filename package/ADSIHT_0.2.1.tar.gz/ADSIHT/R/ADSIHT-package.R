#' @keywords internal
#' @aliases ADSIHT-package
"_PACKAGE"

#' @import Rcpp
#'
#' @useDynLib ADSIHT, .registration=TRUE
NULL
