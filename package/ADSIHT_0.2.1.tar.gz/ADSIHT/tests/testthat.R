library(testthat)
library(ADSIHT)

test_check("ADSIHT")
